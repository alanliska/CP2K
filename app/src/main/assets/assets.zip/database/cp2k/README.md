# Curated Collection of Parameter Data Files

Note that some files are copies of other. Please run `make data` to reconcile.
